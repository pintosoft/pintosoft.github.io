If you want to translate AutoOff, please modify the ini file of the desired language and send it to starcodec@gmail.com.
If there is no ini file for your language here, you can start with the English.ini file.
The file format is in the order of the original text, the equal sign, and the translated text.
"original text"="translated text"

* Do not translate section names.([DIALOGEX], [MENU], [STRINGTABLE])
* "." in the [DIALOGEX] section is a period at the end of a sentence.
* ":" in the [DIALOGEX] section is a separator between hour and minute.
* Translate "Lan&guage" like "Language in your language(Lan&guage)". ex) "Lingvo(Language)"
* Translate "English" to language name in your language. ex) "Esperanto"
