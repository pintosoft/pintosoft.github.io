If you want to translate AutoOff, please modify the ini file of the desired language and send it to starcodec@gmail.com.
If there is no ini file for your language here, you can start with the English.ini file.
The file format is in the order of the original text, the equal sign, and the translated text.
"original text"="translated text"

* Do not translate section names.([DIALOGEX], [MENU], [STRINGTABLE])
* & is the prefix character for the underlined character.
* $1, $2... or %d, %s...  are replacement indicator.
* \t is a tab character.
* \n is a newline character.
* "." in the [DIALOGEX] section is a period at the end of a sentence.
* ":" in the [DIALOGEX] section is a separator between hour and minute.
* Translate "Lan&guage" like "Language in your language(Lan&guage)". ex) "Lan&guage"="Lingvo(Lan&guage)"
* Do not translate language names in [MENU] section.
* "at" is used to indicate the scheduled time. do something "at" a specified time.
* "MMM d " is a format for representing dates.
  "MMM" is an abbreviated month in the local language, ex) "Nov". You can use "M" for a month as digits(1~12).
  "d" is a day of the month as digits(1~31).
  Last space is a separator between date and time.
  ex) "M/d ", "d MMM ", "M d ", "d/M ", "M월 d일 ", "M月d日 "
* Do not change the numbers or symbols.
