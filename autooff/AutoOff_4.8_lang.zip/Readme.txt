If you want to translate AutoOff, please modify the ini file of the desired language and send it to starcodec@gmail.com.
If there is no ini file for your language here, start with the English.ini file.

* Do not translate section names.([DIALOGEX], [MENU], [STRINGTABLE])
* Do not translate foreign languages in the [MENU] section.
* Translate "Lan&guage" like "Translated word(Lan&guage)" in the [MENU] section.
* Do not change two character code(ex. "en") in the [STRINGTABLE] section.
* "." in the [DIALOGEX] section is a period at the end of a sentence.
* ":" in the [DIALOGEX] section is a separator between hour and minute.
