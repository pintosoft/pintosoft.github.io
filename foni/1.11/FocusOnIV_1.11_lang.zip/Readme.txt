If you want to translate FocusOn Image Viewer, please modify the English.ini file and send it to starcodec@gmail.com.
The translated sentences are in the order of the original text, the equal sign, and the translation.
"original text"="translation"

* Do not translate section names.([DIALOGEX], [MENU], [STRINGTABLE])
