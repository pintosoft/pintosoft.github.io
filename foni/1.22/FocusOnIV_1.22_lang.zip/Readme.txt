If you want to translate FocusOn Image Viewer, please modify the ini file of the desired language and send it to support@pintosoft.com.
If there is no ini file for your language here, you can start with the English.ini file.
The file format is in the order of the original text, the equal sign, and the translated text.
"original text"="translated text"

* Do not translate section names.([DIALOGEX], [MENU], [STRINGTABLE])
* Translate "Language" like "Language in your language(Language)". ex) "Lingvo(Language)"
* Translate "English" to language name in your language. ex) "Esperanto"
* "B", "I" and "U" are the text of the Bold, Italic and Underline buttons respectively.
* Do not change the numbers or symbols.