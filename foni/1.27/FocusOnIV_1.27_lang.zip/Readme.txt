If you want to translate FocusOn Image Viewer, please modify the ini file of the desired language and send it to support@pintosoft.com.
If there is no ini file for your language here, you can start with the English.ini file.
The file format is in the order of the original text, the equal sign, and the translated text.
"original text"="translated text"

* Do not translate section names.([DIALOGEX], [MENU], [STRINGTABLE])
* & is the prefix character for the underlined character.
* %d, %s...  are replacement indicator.
* \t is a tab character.
* \n is a newline character.
* Translate "Language" like "Language in your language(Language)". ex) Language="Lingvo(Language)"
* Translate "English" to language name in your language. ex) "English"="Esperanto"
* The phrase starting with 'exif.' is the Exif attribute name. It can be translated like 'exif.Translated Phrase' or skipped.
* "B", "I" and "U" are the text of the Bold, Italic and Underline buttons respectively.
* Do not change the numbers or symbols.
