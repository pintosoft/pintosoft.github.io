QOTD 1.5
September 1, 2003
Copyright 2001-2003, priebesoft
jason_priebe@yahoo.com

          +----------------------------------------------------------+
          |       SPONSORED BY OASIS PROFESSIONAL SERVICES           |
          +----------------------------------------------------------+
          |  Need affordable ad management for your high-traffic     |
          |  Web site?  OASIS is the perfect solution.  Three        |
          |  powerful options:                                       |
          |    - OASIS open-source: free, fast, and easy to use      |
          |    - OASIS Professional: all the power of OASIS open-    |
          |      source, with more features for the power user       |
          |    - OASIS Enterprise: for ultra-high-traffic sites;     |
          |      scales to multiple servers                          |
          |                                                          |
          |  For more information, see http://www.oasispros.com/     |
          +----------------------------------------------------------+


Now compatible with PocketPC, PocketPC 2002, and Novosec's facelift.

This is a "Quote of the Day" Today screen plugin.  It includes a text file with
over 500 interesting quotations.

To install, copy the appropriate CAB file to your device.  Run it from the
File Explorer.  It will copy qotd.dll to \Program Files\priebesoft and
qotd.txt to \My Documents.  Then soft reset your device.  You can activate the
QOTD plugin by going to Settings -> Today and checking the box next to QOTD.

To change the quotes, just replace qotd.txt with a file containing your own
favorites, one per line.  An alternate file, qotd2.txt is also provided.

To uninstall or upgrade, simply rename qotd.dll (to anything else) and soft
reset your device.  You can then remove or replace qotd.dll.

There are some strange issues with resizing -- sometimes you get those nice
gray lines, sometimes you don't.  Sometimes when a new quote is loaded that
is smaller than the previous one, you might see some junk on the screen for
a few seconds.  I have pulled my hair out trying to follow Microsoft's shitty
API docs, and I still can't solve that problem.  Some of the best Today screen
plugins I've seen do it too, so I'm not sure that there's an answer.  If you've
got one, please send it to me.

This software is released under the GPL.  The source is included as a ZIP file
within the main distribution ZIP.

CHANGES

Version 1.5: 
  - now have a nifty installer
  - can opt for a large font now

CREDITS

Riki June <riki@spritesoftware.com> for contributing the following:
  - option to use random or sequential quotes
  - tapping on the screen to cycle to the next quote
  - 385 new quotes
