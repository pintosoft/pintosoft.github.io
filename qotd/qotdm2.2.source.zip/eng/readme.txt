QOTD m2.2
July 21, 2009
http://www.starcodec.com/en/programs/#QOTD
bluesend@gmail.com

[Feature]
QOTD m version is modified verison of QOTD PocketPC Today screen plugin for my own purpose,
displaying a Bible verse.

 - Display a Bible verse on Today screen
 - Support Show all, Scroll, 3/5 line(Max, Fixed) mode
 - Font setting option
 - Line change(\n -> line break, \\ -> \)
 - Support unicode text(UTF-16LE)
 - Support display first line always
 - Support external icon image
 - Change period option
 - Change a text file location

You can change a verse with a double click screen.
You can see next page with a click screen on 3/5 line mode.
You can show an option dialog with a long click screen.
I have modified uncomfortable part and have fixed some bug of a QOTD.
And also I have changed qotd.txt file with Bible verses.

[Install]
1. If you install qotd first time, go to step 4.
2. Go to PPC Settings > Today > Items(tab).
3. Select QOTD to uncheck it and click ok.
4. Execute setup program in a PC and follow it's instructions.
5. You should choose 'Device' for an install location.
6. Go to PPC Settings > Today > Items(tab).
7. Select QOTD to check it and click ok.
8. You can change options in case of need.

* If you would like to install with CAB file, copy CAB to PPC and open it at above step 4.
  qotd.PPC2003.CAB - Pocket PC 2003 version
  qotd.MOBILE.CAB - Windows Mobile 5.0 version

* This is not compatible with a 1.5 and below verison. You must uninstall it before installation.

[etc]
You can choose a file on the My Documents folder as text file for syncing that file with a PC.
You can change \Program Files\QOTD\qotd.bmp for display different icon. This icon size should be 16*16.

This software is released under the GPL. You can download a source file from
'http://www.starcodec.com/en/programs/#QOTD'.

[Changes]
m2.2
 - fix a bug not showing last line of long text
 - show an option dialog with a long click
 - fix a bug period option value
 - add an option for changing a qotd.txt text file location

m2.1
 - first english verison
