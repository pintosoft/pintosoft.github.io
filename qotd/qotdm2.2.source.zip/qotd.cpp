// qotd.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "resource.h"

#define TOPMARGIN 1
#define LEFTMARGIN 2
#define RIGHTMARGIN 2
#define BOTTOMMARGIN 1
#define ICON_WIDTH	22
#define MINHEIGHT 18
#define SCROLL_MARGIN 36

#ifdef LANG_ENG
	#pragma message("english compile")
	#define DEFAULT_FONTNAME L"Tahoma"
#else
	#define DEFAULT_FONTNAME L"����"
#endif

#define DEFAULT_FONTSIZE 12
#define DEFAULT_FONTSIZE_TEXT L"12"

#define DEFAULT_SCROLL_SPEED 4
#define DEFAULT_SCROLL_SPEED_TEXT L"4"

#define TIMER_ID_SCROLL		100
#define TIMER_ID_ELAPSE		200

#define MAX_LINE_LEN		1024

HINSTANCE Instance;
BOOL Refresh = FALSE;

HBITMAP g_hIconBmp;
//HBITMAP g_hMaskBmp;
HDC g_hIconDC;

time_t g_currTime = 0;
DWORD g_numQuotes = 0;
DWORD g_quoteNum = 0;
int g_pageHeight = 0;
int g_pageNum = 0;
int g_pageMax = 1;
int g_scrollPos = 0;
int g_scrollMax = SCROLL_MARGIN;
int g_idTimer = 0;

//LPWSTR g_message = new WCHAR[512];
WCHAR g_message[MAX_LINE_LEN];
WCHAR g_path[MAX_PATH];

int g_oldWidth = 0;
int g_oldHeight = 0;

// a global varable that stores the plugin options
struct _myOptions {
	int mode;
	int nScrollSpeed;
	WCHAR szPath[MAX_PATH];
	WCHAR szFontName[LF_FACESIZE];
	LONG nFontSize;
	LONG nFontWeight;
	bool seq;
	bool alwaysOne;
	bool icon;
	int nTimeUnit;
	int nTime;
} ;
_myOptions g_options;

#ifndef TODAYM_DRAWWATERMARK
 #define TODAYM_GETCOLOR     (WM_USER + 100)
 #define TODAYCOLOR_TEXT     0x10000004

 #define TODAYM_DRAWWATERMARK   (WM_USER + 101)
 typedef struct
 {
    HDC hdc;
    RECT rc;
    HWND hwnd;
 } TODAYDRAWWATERMARKINFO;
#endif

time_t time(time_t *pt)
{
	typedef union
	{
		FILETIME		ft;
		ULARGE_INTEGER	u64;
	} FT_U64;

	time_t _t;
	SYSTEMTIME syst;
	FT_U64 ft_u64;

	GetSystemTime(&syst);
	if (SystemTimeToFileTime(&syst, &ft_u64.ft))
		_t = (time_t)((ft_u64.u64.QuadPart - 0x19db1ded53e8000) / 10000000);
	else
		_t = 0;

	if (pt)
		*pt = _t;

	return _t;
} 


bool IsNextQuoteTime(time_t newTime)
{
/*	DATE dNow;
	SYSTEMTIME st;
	GetLocalTime(&st);
	SystemTimeToVariantTime(&st, &dNow);
	return (DWORD)dNow;
*/
	time_t time1, time2;
	switch (g_options.nTimeUnit)
	{
	case 0:// day
		time1 = g_currTime / (60 * 60 * 24);
		time2 = newTime / (60 * 60 * 24);
		return (time2 - time1) >= (time_t)g_options.nTime;
	case 1:// hour
		time1 = g_currTime / (60 * 60);
		time2 = newTime / (60 * 60);
		return (time2 - time1) >= (time_t)g_options.nTime;
	case 2:// min
		time1 = g_currTime / 60;
		time2 = newTime / 60;
		return (time2 - time1) >= (time_t)g_options.nTime;
	case 3:// sec
		return (newTime - g_currTime) >= (time_t)g_options.nTime;
	}
	return false;
}

int WINAPI CALLBACK EnumFontFamProc(CONST LOGFONT *lplf, CONST TEXTMETRIC *lpntm, DWORD FontType, LPARAM lParam)
{
	HWND hWnd = (HWND)lParam;
	::SendMessage(hWnd, CB_ADDSTRING, 0, (LPARAM)lplf->lfFaceName);
	return TRUE;
}

BOOL APIENTRY CustomItemOptionsDlgProc(HWND hDlg, UINT message,
  UINT wParam, LONG lParam)
{
#ifdef LANG_ENG
	LPCWSTR aModes[] = {L"Show all", L"Scroll", L"Max 3 lines", L"Fixed 3 lines", L"Max 5 lines", L"Fixed 5 lines"};
	LPCWSTR aScrollSpeeds[] = {L"1", L"2", L"3", L"4", L"5", L"8", L"10", L"15", L"20", L"50", L"80"};
	LPCWSTR aFontSizes[] = {L"8", L"9", L"10", L"11", L"12", L"14", L"16", L"20", L"24", L"28", L"36", L"72"};
	LPCWSTR aTimeUnits[] = {L"days", L"hours", L"mins", L"secs"};
#else
	LPCWSTR aModes[] = {L"��ü ����", L"��ũ��", L"�ִ� 3�� ����", L"���� 3�� ����", L"�ִ� 5�� ����", L"���� 5�� ����"};
	LPCWSTR aScrollSpeeds[] = {L"1", L"2", L"3", L"4", L"5", L"8", L"10", L"15", L"20", L"50", L"80"};
	LPCWSTR aFontSizes[] = {L"8", L"9", L"10", L"11", L"12", L"14", L"16", L"20", L"24", L"28", L"36", L"72"};
	LPCWSTR aTimeUnits[] = {L"��", L"�ð�", L"��", L"��"};
#endif
	static bool seq = false;

	switch (message) 
	{
		case WM_INITDIALOG:
			{
				// create combobox
				RECT rc;
#ifdef LANG_ENG
				::SetRect(&rc, 25, 17, 59, 93);
#else
				::SetRect(&rc, 23, 17, 59, 93);
#endif
				::MapDialogRect(hDlg, &rc);
				::CreateWindow(_T("COMBOBOX"), NULL,
			        WS_CHILD | CBS_DROPDOWNLIST | WS_VISIBLE | WS_VSCROLL | WS_TABSTOP, rc.left, rc.top, rc.right, rc.bottom,
					hDlg, (HMENU)IDC_MODE, Instance, NULL);
#ifdef LANG_ENG
				::SetRect(&rc, 86, 17, 31, 93);
#else
				::SetRect(&rc, 84, 17, 31, 93);
#endif
				::MapDialogRect(hDlg, &rc);
				::CreateWindow(_T("COMBOBOX"), NULL,
			        WS_CHILD | CBS_DROPDOWNLIST | WS_VISIBLE | WS_VSCROLL | WS_TABSTOP, rc.left, rc.top, rc.right, rc.bottom,
					hDlg, (HMENU)IDC_SCROLL_SPEED, Instance, NULL);
#ifdef LANG_ENG
				::SetRect(&rc, 25, 31, 59, 91);
#else
				::SetRect(&rc, 23, 33, 59, 91);
#endif
				::MapDialogRect(hDlg, &rc);
				::CreateWindow(_T("COMBOBOX"), NULL,
			        WS_CHILD | CBS_DROPDOWNLIST | WS_VISIBLE | WS_VSCROLL | WS_TABSTOP, rc.left, rc.top, rc.right, rc.bottom,
					hDlg, (HMENU)IDC_FONTNAME, Instance, NULL);
#ifdef LANG_ENG
				::SetRect(&rc, 86, 31, 31, 91);
#else
				::SetRect(&rc, 84, 33, 31, 91);
#endif
				::MapDialogRect(hDlg, &rc);
				::CreateWindow(_T("COMBOBOX"), NULL,
			        WS_CHILD | CBS_DROPDOWNLIST | WS_VISIBLE | WS_VSCROLL | WS_TABSTOP, rc.left, rc.top, rc.right, rc.bottom,
					hDlg, (HMENU)IDC_FONTSIZE, Instance, NULL);
#ifdef LANG_ENG
				::SetRect(&rc, 80, 64, 30, 58);
#else
				::SetRect(&rc, 32, 74, 24, 58);
#endif
				::MapDialogRect(hDlg, &rc);
				::CreateWindow(_T("COMBOBOX"), NULL,
			        WS_CHILD | CBS_DROPDOWNLIST | WS_VISIBLE | WS_VSCROLL | WS_TABSTOP, rc.left, rc.top, rc.right, rc.bottom,
					hDlg, (HMENU)IDC_TIMEUNIT, Instance, NULL);
				int i;
				// mode
				for (i = 0; i < sizeof(aModes) / sizeof(aModes[0]); i++)
					::SendMessage(GetDlgItem(hDlg, IDC_MODE), CB_ADDSTRING, 0, (LPARAM)aModes[i]);
				for (i = 0; i < sizeof(aScrollSpeeds) / sizeof(aScrollSpeeds[0]); i++)
					::SendMessage(GetDlgItem(hDlg, IDC_SCROLL_SPEED), CB_ADDSTRING, 0, (LPARAM)aScrollSpeeds[i]);
				// font setting
				HDC hdc = ::GetDC(hDlg);
				::EnumFontFamilies(hdc, NULL, EnumFontFamProc, (LPARAM)GetDlgItem(hDlg, IDC_FONTNAME));
				::ReleaseDC(hDlg, hdc);
				for (i = 0; i < sizeof(aFontSizes) / sizeof(aFontSizes[0]); i++)
					::SendMessage(GetDlgItem(hDlg, IDC_FONTSIZE), CB_ADDSTRING, 0, (LPARAM)aFontSizes[i]);
				// time unit
				for (i = 0; i < sizeof(aTimeUnits) / sizeof(aTimeUnits[0]); i++)
					::SendMessage(GetDlgItem(hDlg, IDC_TIMEUNIT), CB_ADDSTRING, 0, (LPARAM)aTimeUnits[i]);
				// get options from registry
				unsigned long val;
				HKEY hkResult;
				DWORD type;
				DWORD size;
				DWORD RetVal = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Software\\Microsoft\\Today\\Items\\QOTD", 0, 0, &hkResult);
				if (RetVal == ERROR_SUCCESS)
				{
					WCHAR szPath[MAX_PATH];
					size = sizeof(szPath);
					if (RegQueryValueEx(hkResult, L"Path", NULL, &type, (unsigned char *)szPath, &size) != ERROR_SUCCESS || (type != REG_SZ))
					{
						GetModuleFileName(Instance, szPath, MAX_PATH);
						WCHAR *pName = wcsrchr(szPath, L'\\');
						*pName = 0;
						wcscat(szPath, L"\\qotd.txt");
					}
					SetWindowText(GetDlgItem(hDlg, IDC_PATH), szPath);

					size = sizeof(DWORD);
					if (RegQueryValueEx(hkResult, L"Mode", NULL, &type, (unsigned char *) &val, &size) == ERROR_SUCCESS)
						SendMessage(GetDlgItem(hDlg, IDC_MODE), CB_SETCURSEL, val, 0);
					else
						SendMessage(GetDlgItem(hDlg, IDC_MODE), CB_SETCURSEL, 0, 0);
					EnableWindow(GetDlgItem(hDlg, IDC_SCROLL_SPEED), val == 1);


					size = sizeof(DWORD);
					if (RegQueryValueEx(hkResult, L"ScrollSpeed", NULL, &type, (unsigned char *) &val, &size) == ERROR_SUCCESS)
					{
						WCHAR szScrollSpeed[20];
						SendMessage(GetDlgItem(hDlg, IDC_SCROLL_SPEED), CB_SELECTSTRING, -1, (LPARAM)_ultow(val, szScrollSpeed, 10));
					}
					else
						SendMessage(GetDlgItem(hDlg, IDC_SCROLL_SPEED), CB_SELECTSTRING, -1, (LPARAM)DEFAULT_SCROLL_SPEED_TEXT);

					WCHAR szFontName[LF_FACESIZE];
					size = sizeof(szFontName);
					if (RegQueryValueEx(hkResult, L"FontName", NULL, &type, (unsigned char *)szFontName, &size) == ERROR_SUCCESS && (type == REG_SZ))
						SendMessage(GetDlgItem(hDlg, IDC_FONTNAME), CB_SELECTSTRING, -1, (LPARAM)szFontName);
					else
						SendMessage(GetDlgItem(hDlg, IDC_FONTNAME), CB_SELECTSTRING, -1, (LPARAM)DEFAULT_FONTNAME);
					size = sizeof(DWORD);
					if (RegQueryValueEx(hkResult, L"FontSize", NULL, &type, (unsigned char *)&val, &size) == ERROR_SUCCESS)
					{
						WCHAR szFontSize[20];
						SendMessage(GetDlgItem(hDlg, IDC_FONTSIZE), CB_SELECTSTRING, -1, (LPARAM)_ultow(val, szFontSize, 10));
					}
					else
						SendMessage(GetDlgItem(hDlg, IDC_FONTSIZE), CB_SELECTSTRING, -1, (LPARAM)DEFAULT_FONTSIZE_TEXT);

					size = sizeof(DWORD);
					if (RegQueryValueEx(hkResult, L"FontWeight", NULL, &type, (unsigned char *)&val, &size) == ERROR_SUCCESS && (val > FW_NORMAL))
						SendMessage(GetDlgItem(hDlg, IDC_BOLD), BM_SETCHECK, BST_CHECKED, 0);
					else
						SendMessage(GetDlgItem(hDlg, IDC_BOLD), BM_SETCHECK, BST_UNCHECKED, 0);

					size = sizeof(DWORD);
					if (RegQueryValueEx( hkResult, L"Seq", NULL, &type, (unsigned char *) &val, &size) == ERROR_SUCCESS && val)
					{
						SendMessage(GetDlgItem(hDlg, IDC_CHECKSEQ), BM_SETCHECK, BST_CHECKED, 0);
						seq = true;
					}
					else
					{
						SendMessage(GetDlgItem(hDlg, IDC_CHECKSEQ), BM_SETCHECK, BST_UNCHECKED, 0);
						seq = false;
					}

					size = sizeof(DWORD);
					if (RegQueryValueEx( hkResult, L"AlwaysOne", NULL, &type, (unsigned char *) &val, &size) == ERROR_SUCCESS && val)
						SendMessage(GetDlgItem(hDlg, IDC_ALWAYSONE), BM_SETCHECK, BST_CHECKED, 0);
					else
						SendMessage(GetDlgItem(hDlg, IDC_ALWAYSONE), BM_SETCHECK, BST_UNCHECKED, 0);
					size = sizeof(DWORD);
					if (RegQueryValueEx( hkResult, L"Icon", NULL, &type, (unsigned char *) &val, &size) != ERROR_SUCCESS || val)
						SendMessage(GetDlgItem(hDlg, IDC_SHOWICON), BM_SETCHECK, BST_CHECKED, 0);
					else
						SendMessage(GetDlgItem(hDlg, IDC_SHOWICON), BM_SETCHECK, BST_UNCHECKED, 0);
					size = sizeof(DWORD);
					if (RegQueryValueEx(hkResult, L"Time", NULL, &type, (unsigned char *) &val, &size) == ERROR_SUCCESS)
					{
						WCHAR szTime[20];
						SetWindowText(GetDlgItem(hDlg, IDC_TIME), _ultow(val, szTime, 10));
					}
					else
						SetWindowText(GetDlgItem(hDlg, IDC_TIME), L"1");

					size = sizeof(DWORD);
					if (RegQueryValueEx(hkResult, L"TimeUnit", NULL, &type, (unsigned char *) &val, &size) == ERROR_SUCCESS)
						SendMessage(GetDlgItem(hDlg, IDC_TIMEUNIT), CB_SETCURSEL, val, 0);
					else
						SendMessage(GetDlgItem(hDlg, IDC_TIMEUNIT), CB_SETCURSEL, 0, 0);

					RegCloseKey(hkResult);
				}

				SHMENUBARINFO mbi;

				memset(&mbi, 0, sizeof(SHMENUBARINFO));
				mbi.cbSize = sizeof(SHMENUBARINFO);
				mbi.hwndParent = hDlg;
				mbi.dwFlags = SHCMBF_EMPTYBAR;
				mbi.nToolBarId = 0;
				mbi.hInstRes = 0;
				mbi.nBmpId = 0;
				mbi.cBmpImages = 0;
				mbi.hwndMB = 0;

				SHCreateMenuBar(&mbi);

				SHINITDLGINFO shidi;
				shidi.dwMask = SHIDIM_FLAGS;
				shidi.dwFlags = SHIDIF_DONEBUTTON | SHIDIF_SIZEDLGFULLSCREEN;
				shidi.hDlg = hDlg;
				SHInitDialog(&shidi);

				return TRUE; 
			}
		//case WM_SETFOCUS:
		//	SHFullScreen(hDlg, SHFS_HIDESIPBUTTON);
		//	break;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK) {
				// save options back to registry
				unsigned long val;
				HKEY hkResult;
				DWORD RetVal = RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Software\\Microsoft\\Today\\Items\\QOTD", 0, 0, &hkResult);
				if (RetVal == ERROR_SUCCESS){
					WCHAR szPath[MAX_PATH];
					if (GetWindowText(GetDlgItem(hDlg, IDC_PATH), szPath, MAX_PATH) > 0)
					{
						wcscpy(g_options.szPath, szPath);
						RegSetValueEx(hkResult, L"Path", NULL, REG_SZ, (unsigned char *)&szPath, (wcslen(szPath) + 1) * sizeof(WCHAR));
					}

					val = SendMessage(GetDlgItem(hDlg, IDC_MODE), CB_GETCURSEL, 0, 0);
					if (val != CB_ERR)
					{
						g_options.mode = val;
						RegSetValueEx(hkResult, L"Mode", NULL, REG_DWORD, (unsigned char *)&val, sizeof(DWORD));
					}

					WCHAR szScrollSpeed[20];
					if (GetWindowText(GetDlgItem(hDlg, IDC_SCROLL_SPEED), szScrollSpeed, 20) > 0)
					{
						val = _wtol(szScrollSpeed);
						g_options.nScrollSpeed = val;
						RegSetValueEx( hkResult, L"ScrollSpeed", NULL, REG_DWORD, (unsigned char *)&val, sizeof(DWORD));
					}

					WCHAR szFontName[LF_FACESIZE];
					if (GetWindowText(GetDlgItem(hDlg, IDC_FONTNAME), szFontName, LF_FACESIZE) > 0)
					{
						wcscpy(g_options.szFontName, szFontName);
						RegSetValueEx(hkResult, L"FontName", NULL, REG_SZ, (unsigned char *)&szFontName, (wcslen(szFontName) + 1) * sizeof(WCHAR));
					}

					WCHAR szFontSize[20];
					if (GetWindowText(GetDlgItem(hDlg, IDC_FONTSIZE), szFontSize, 20) > 0)
					{
						val = _wtol(szFontSize);
						g_options.nFontSize = val;
						RegSetValueEx( hkResult, L"FontSize", NULL, REG_DWORD, (unsigned char *)&val, sizeof(DWORD));
					}

					if (SendMessage(GetDlgItem(hDlg, IDC_BOLD), BM_GETCHECK, 0, 0) == BST_CHECKED)
					{
						g_options.nFontWeight = FW_BOLD;
						val = FW_BOLD;
					}
					else
					{
						g_options.nFontWeight = FW_NORMAL;
						val = FW_NORMAL;
					}
					RegSetValueEx( hkResult, L"FontWeight", NULL, REG_DWORD, (unsigned char *) &val, sizeof(DWORD));

					if (SendMessage(GetDlgItem(hDlg, IDC_CHECKSEQ), BM_GETCHECK, 0, 0) == BST_CHECKED)
					{
						val = 0;
						if (!seq)
						{
							// Init seq to 0
							RegSetValueEx( hkResult, L"SeqNo", NULL, REG_DWORD, (unsigned char *) &val, sizeof(DWORD));
							g_options.seq = true;
						}
						val = 1;
					}
					else
					{
						g_options.seq = false;
						val = 0;
					}
					RegSetValueEx( hkResult, L"Seq", NULL, REG_DWORD, (unsigned char *) &val, sizeof(DWORD));

					if (SendMessage(GetDlgItem(hDlg, IDC_ALWAYSONE), BM_GETCHECK, 0, 0) == BST_CHECKED)
					{
						g_options.alwaysOne = true;
						val = 1;
					}
					else
					{
						g_options.alwaysOne = false;
						val = 0;
					}
					RegSetValueEx( hkResult, L"AlwaysOne", NULL, REG_DWORD, (unsigned char *) &val, sizeof(DWORD));

					if (SendMessage(GetDlgItem(hDlg, IDC_SHOWICON), BM_GETCHECK, 0, 0) == BST_CHECKED)
					{
						g_options.icon = true;
						val = 1;
					}
					else
					{
						g_options.icon = false;
						val = 0;
					}
					RegSetValueEx( hkResult, L"Icon", NULL, REG_DWORD, (unsigned char *) &val, sizeof(DWORD));

					WCHAR szTime[20];
					if (GetWindowText(GetDlgItem(hDlg, IDC_TIME), szTime, 20) > 0)
					{
						val = _wtol(szTime);
						g_options.nTime = val;
						RegSetValueEx( hkResult, L"Time", NULL, REG_DWORD, (unsigned char *)&val, sizeof(DWORD));
					}
					val = SendMessage(GetDlgItem(hDlg, IDC_TIMEUNIT), CB_GETCURSEL, 0, 0);
					if (val != CB_ERR)
					{
						g_options.nTimeUnit = val;
						RegSetValueEx(hkResult, L"TimeUnit", NULL, REG_DWORD, (unsigned char *)&val, sizeof(DWORD));
					}


					RegCloseKey(hkResult);
				}

				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			if (LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			if (LOWORD(wParam) == IDC_MODE)
			{
				if (HIWORD(wParam) == CBN_SELCHANGE)
				{
					BOOL bEnable = SendMessage((HWND)lParam, CB_GETCURSEL, 0, 0) == 1;
					EnableWindow(GetDlgItem(hDlg, IDC_SCROLL_SPEED), bEnable);
				}
				return TRUE;
			}
			if (LOWORD(wParam) == IDC_BROWSE)
			{
				WCHAR szPath[MAX_PATH] = {0};
				WCHAR szDir[MAX_PATH] = {0};

				GetWindowText(GetDlgItem(hDlg, IDC_PATH), szPath, MAX_PATH);
				wcscpy(szDir, szPath);
				WCHAR *pName = wcsrchr(szDir, L'\\');
				*pName = 0;

#if _WIN32_WCE > 0x500
				OPENFILENAMEEX ofn;
				memset(&ofn, 0, sizeof(ofn));
				ofn.lStructSize = sizeof(ofn);
				ofn.hwndOwner = hDlg;
#ifdef LANG_ENG
				ofn.lpstrFilter = L"Text Files (*.txt)\0*.txt\0";
				ofn.lpstrTitle = L"Select text file";
#else
				ofn.lpstrFilter = L"�ؽ�Ʈ ���� (*.txt)\0*.txt\0";
				ofn.lpstrTitle = L"�ؽ�Ʈ ���� ����";
#endif
				ofn.nFilterIndex = 1;
				ofn.lpstrFile = szPath;
				ofn.nMaxFile = MAX_PATH;
				ofn.lpstrInitialDir = szDir;
				ofn.Flags = OFN_FILEMUSTEXIST;
				ofn.ExFlags = OFN_EXFLAG_DETAILSVIEW;

				if (GetOpenFileNameEx(&ofn))
					SetWindowText(GetDlgItem(hDlg, IDC_PATH), szPath);
#else
				OPENFILENAME ofn;
				memset(&ofn, 0, sizeof(ofn));
				ofn.lStructSize = sizeof(ofn);
				ofn.hwndOwner = hDlg;
#ifdef LANG_ENG
				ofn.lpstrFilter = L"Text Files (*.txt)\0*.txt\0";
#else
				ofn.lpstrFilter = L"�ؽ�Ʈ ���� (*.txt)\0*.txt\0";
#endif
				ofn.nFilterIndex = 1;
				ofn.lpstrFile = szPath;
				ofn.nMaxFile = MAX_PATH;
				ofn.lpstrInitialDir = szDir;
				ofn.Flags = OFN_FILEMUSTEXIST;

				if (GetOpenFileName(&ofn))
					SetWindowText(GetDlgItem(hDlg, IDC_PATH), szPath);
#endif
				return TRUE;
			}
			if (LOWORD(wParam) == IDC_DEFAULT)
			{
				WCHAR szPath[MAX_PATH] = {0};
				GetModuleFileName(Instance, szPath, MAX_PATH);
				WCHAR *pName = wcsrchr(szPath, L'\\');
				*pName = 0;
				wcscat(szPath, L"\\qotd.txt");
				SetWindowText(GetDlgItem(hDlg, IDC_PATH), szPath);
			}
			break;
/*		case WM_DESTROY:
			{
				return TRUE; 
			}*/
		default:
			return DefWindowProc(hDlg, message, wParam, lParam);
   }
   return 0;
}


DWORD getNextSeq()
{
    HKEY hkResult;
    DWORD type;
    DWORD size;
    DWORD ret = 0;
	DWORD seqval = 0;

    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Software\\Microsoft\\Today\\Items\\QOTD", 0, 0, &hkResult) == ERROR_SUCCESS) {
        RegQueryValueEx( hkResult, L"SeqNo", NULL, &type, (unsigned char *) & ret, &size);
        seqval = (ret + 1) % g_numQuotes;
        RegSetValueEx( hkResult, L"SeqNo", NULL, REG_DWORD, (unsigned char *) &seqval, sizeof(DWORD));
        RegSetValueEx( hkResult, L"NumQuotes", NULL, REG_DWORD, (unsigned char *) &g_numQuotes, sizeof(DWORD));
        RegCloseKey(hkResult);
     }

    return ret % g_numQuotes;
}


void formatQuote(WCHAR* szQuote)
{
	WCHAR* pSrc = szQuote;
	WCHAR* pDest = szQuote;
	while (*pSrc != 0)
	{
		if (*pSrc == L'\\')
		{
			if (*(pSrc + 1) == L'\\')
			{
				*pDest = L'\\';
				pSrc++;
				pSrc++;
				pDest++;
				continue;
			}
			else if (*(pSrc + 1) == L'n')
			{
				*pDest = L'\n';
				pSrc++;
				pSrc++;
				pDest++;
				continue;
			}
		}
		else if ((*pSrc == L'\n') || (*pSrc == L'\r'))
		{
			pSrc++;
			continue;
		}
		*pDest = *pSrc;
		pSrc++;
		pDest++;
	}
	*pDest = 0;
}

void setNewQuote()
{
	FILE *fp = _wfopen(g_options.szPath, L"rb");
	if (fp)
	{
		bool fUnicode;
		DWORD i;
		wint_t ch = fgetwc(fp);
		fUnicode = (ch == L'\xFEFF');

		if (!fUnicode)
		{
			fclose(fp);
			FILE *fp = _wfopen(g_options.szPath, L"r");
		}

		for (i = 0; i < MAX_LINE_LEN; i++) {
			g_message[i] = 0;
		}
		g_numQuotes = 0;
		g_pageNum = 0;
		g_scrollPos = 0;

		WCHAR junk_message[MAX_LINE_LEN];

		while (fgetws (junk_message, MAX_LINE_LEN, fp))
		{
			if (wcslen(junk_message) != 0)
				g_numQuotes++;
		}

		if (fUnicode)
			fseek(fp, 2, SEEK_SET);
		else
			fseek(fp, 0, SEEK_SET);

		if (g_options.seq == false)
			g_quoteNum = rand() % g_numQuotes;
		else {
			// get options from registry
			g_quoteNum = getNextSeq();
		}

		i = 0;
		while (i < g_quoteNum)
		{
			if ((i == 0) && g_options.alwaysOne)
			{
				fgetws(g_message, MAX_LINE_LEN, fp);
				if (wcslen(g_message) != 0)
				{
					formatQuote(g_message);
					i++;
				}
			}
			else
			{
				fgetws(junk_message, MAX_LINE_LEN, fp);
				if (wcslen(junk_message) != 0)
					i++;
			}
		}
		size_t len = wcslen(g_message);
		fgetws(g_message + len, MAX_LINE_LEN - len, fp);
		formatQuote(g_message + len);
		fclose(fp);
	}
}


HFONT CreateQuickFont(HDC hDC, int nWeight, int nHeight, LPTSTR szFaceName)
{
	LOGFONT lf;

	lf.lfWeight=nWeight;
	lf.lfEscapement=0;
	lf.lfOrientation=0;
	lf.lfHeight = SCALEY(nHeight);
	lf.lfWidth=0;
	lf.lfCharSet=DEFAULT_CHARSET;
	lf.lfClipPrecision=CLIP_DEFAULT_PRECIS;
	lf.lfItalic=FALSE;
	lf.lfUnderline=FALSE;
	lf.lfStrikeOut=FALSE;
	lf.lfQuality=DEFAULT_QUALITY;
	lf.lfOutPrecision=OUT_DEFAULT_PRECIS;
	lf.lfPitchAndFamily=DEFAULT_PITCH;

	lstrcpy(lf.lfFaceName,szFaceName);

	return(CreateFontIndirect(&lf));
}

void DrawQuote(HWND hwnd, HDC hdc)
{
	RECT rc;

	GetClientRect(hwnd, &rc);
	rc.top += TOPMARGIN;
	rc.left += LEFTMARGIN;
	rc.right -= RIGHTMARGIN;
	rc.bottom -= BOTTOMMARGIN;

	HFONT hfOld = (HFONT) SelectObject(hdc, CreateQuickFont(hdc, g_options.nFontWeight, g_options.nFontSize, g_options.szFontName));

	// we really ought to use some combination of MaskBlt() as shown below,
	// because TransparentImage() has resource and/or memory leaks, but I couldn't
	// get MaskBlt() to work right, so I reverted to TransparentImage()
	if (g_options.icon)
	{
		TransparentImage(hdc, 2, 1 + TOPMARGIN, 16, 16, g_hIconBmp, 0, 0, 16, 16, RGB (255, 0, 255));
		rc.left += ICON_WIDTH;
	}

	SetBkMode(hdc, TRANSPARENT);

	COLORREF  crText;
	if (crText = SendMessage(GetParent(hwnd), TODAYM_GETCOLOR, (WPARAM) TODAYCOLOR_TEXT, NULL))
		SetTextColor(hdc, crText);

	switch (g_options.mode)
	{
	case 0:
		DrawText(hdc, g_message, wcslen(g_message), &rc, DT_WORDBREAK);
		break;
	case 1:
		IntersectClipRect(hdc, rc.left, TOPMARGIN, rc.right, rc.bottom);
		rc.left -= g_scrollPos;
		DrawText(hdc, g_message, wcslen(g_message), &rc, DT_SINGLELINE|DT_VCENTER);
		rc.left += g_scrollMax;
		if (rc.left < rc.right)
			DrawText(hdc, g_message, wcslen(g_message), &rc, DT_SINGLELINE|DT_VCENTER);
		break;
	default:
		rc.top -= g_pageNum * g_pageHeight;
		IntersectClipRect(hdc, rc.left, TOPMARGIN, rc.right, rc.bottom);
		DrawText(hdc, g_message, wcslen(g_message), &rc, DT_WORDBREAK);
		break;
	}
	
	DeleteObject(SelectObject(hdc, hfOld));
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
  static bool resized = true;
  static bool pressed = false;
  static DWORD timePressed;
  static int xPressed;
  static int yPressed;

  switch (msg) {
    case WM_TODAYCUSTOM_CLEARCACHE:
      break;

	case WM_LBUTTONDOWN:
		pressed = true;
		timePressed = GetTickCount();
		xPressed = LOWORD(lparam);
		yPressed = HIWORD(lparam);
		return 0;

	case WM_MOUSEMOVE:
		if (pressed)
		{
			if ((abs(xPressed - LOWORD(lparam)) > 10)
				|| (abs(yPressed - HIWORD(lparam)) > 10))
				pressed = false;
		}
		return 0;

	case WM_LBUTTONUP:
		{
			if (pressed)
			{
				DWORD timeElapsed = GetTickCount() - timePressed;
				if (timeElapsed > 1000)
				{
					if (DialogBox(Instance, MAKEINTRESOURCE(IDD_TODAY_CUSTOM), hwnd, CustomItemOptionsDlgProc) == IDOK)
						resized = true;
				}
				else if ((LOWORD(lparam) >= LEFTMARGIN) && (g_pageMax > 1))
				{
					g_pageNum = (g_pageNum + 1) % g_pageMax;
					InvalidateRect(hwnd, NULL, TRUE);
				}
				pressed = false;
			}
		}
		return 0;

	case WM_LBUTTONDBLCLK:
		if (LOWORD(lparam) >= LEFTMARGIN)
		{
			setNewQuote();
			resized = true;
			InvalidateRect(hwnd, NULL, TRUE);
		}
		return 0;
/*
	case WM_MOVE:
	{
		DWORD newpos=HIWORD(lparam);
		static DWORD lastpos=0;

		DWORD movement=abs(newpos-lastpos);
		if (movement!=0){
			if (movement<4){
				SetWindowPos(hwnd,HWND_TOP,0,lastpos,0,0,0);
			}else{
				lastpos=newpos;
			}
		}
		return 0;
	}
*/

	case WM_ERASEBKGND:
		return TRUE;

    case WM_TODAYCUSTOM_QUERYREFRESHCACHE:
		{
			int width;
			int height;
			int newHeight;
			RECT rc;
			GetClientRect(hwnd, &rc);

			time_t newTime = time(NULL);
			if (IsNextQuoteTime(newTime))
			{
				g_currTime = newTime;
				setNewQuote();
				resized = true;
			}
			else
			{
				// scroll
				switch (g_options.mode)
				{
				case 1:
					if (g_idTimer == 0)
						g_idTimer = ::SetTimer(hwnd, TIMER_ID_SCROLL, TIMER_ID_ELAPSE, NULL);
					break;
				}
			}
			
			width = rc.right - rc.left;
			height = rc.bottom - rc.top - TOPMARGIN - BOTTOMMARGIN;
			if (!resized && (width == g_oldWidth) && (height == g_oldHeight))
				return FALSE;
			resized = false;

			
			HDC hdc = GetDC (hwnd);
			HFONT hfOld = (HFONT) SelectObject(hdc, CreateQuickFont(hdc, g_options.nFontWeight, g_options.nFontSize, g_options.szFontName));
			// bluesend@gmail.com 20060412
			//if (rc.right == 0)
			//rc.right = 240;
			rc.top += TOPMARGIN;
			rc.left += LEFTMARGIN;
			rc.right -= RIGHTMARGIN;
			rc.bottom = rc.top;
			if (g_options.icon)
				rc.left += ICON_WIDTH;
			
			UINT uFormat;
			
			switch (g_options.mode)
			{
			case 1:
				uFormat = DT_CALCRECT | DT_SINGLELINE;
				break;
			default:
				uFormat = DT_CALCRECT | DT_WORDBREAK;
				break;
			}
			
			newHeight = DrawText(hdc, g_message, wcslen(g_message), &rc, uFormat);
			
			DeleteObject(SelectObject(hdc, hfOld));
			
			ReleaseDC(hwnd, hdc);
			
			if (newHeight < MINHEIGHT)
				newHeight = MINHEIGHT;
			
			switch (g_options.mode)
			{
			case 0:
				break;
			case 1:
				if (g_scrollMax != ((rc.right - rc.left) + SCROLL_MARGIN))
				{
					g_scrollMax = (rc.right - rc.left) + SCROLL_MARGIN;
					g_scrollPos %= g_scrollMax;
				}
				break;
			default:
				{
					int line = 3;
					switch (g_options.mode)
					{
					case 4:
					case 5:
						line = 5;
						break;
					}

					g_pageHeight = SCALEY(g_options.nFontSize) * line;
					if (newHeight > g_pageHeight)
					{
						g_pageMax = ((newHeight - 1) / g_pageHeight) + 1;
						g_pageNum %= g_pageMax;
						newHeight = g_pageHeight;
					}
					else
						g_pageMax = 1;
					if (g_options.mode % 2)
						newHeight = g_pageHeight;
				}
				break;
			}
			
			if (newHeight != height)
			{
				((TODAYLISTITEM *)(wparam))->cyp = newHeight + TOPMARGIN + BOTTOMMARGIN;
				//resized = true;
			}
			
			g_oldWidth = width;
			g_oldHeight = newHeight;
		}

  	  return TRUE;

/*	case WM_SIZE:
		{
			WORD nWidth  = LOWORD(lparam);
			WORD nHeight = HIWORD(lparam);
			GetWindowRect(hwnd, &rect);
			MoveWindow(hwnd, 0, rect.top, nWidth, nHeight, FALSE);
		}
		break;*/


    case WM_PAINT:
		{
		PAINTSTRUCT ps;
		RECT rc;
		int nWidth;
		int nHeight;

		HDC hdc = CreateCompatibleDC(BeginPaint(hwnd, &ps));
		GetClientRect(hwnd, &rc);
		nWidth = rc.right - rc.left;
		nHeight = rc.bottom - rc.top;
		HBITMAP hbmOld = (HBITMAP)SelectObject(hdc, CreateCompatibleBitmap(ps.hdc, nWidth, nHeight));

		TODAYDRAWWATERMARKINFO dwi;
		
		dwi.hdc = hdc;
		dwi.rc = rc;
		dwi.hwnd = hwnd;
		if (!SendMessage(GetParent(hwnd), TODAYM_DRAWWATERMARK, 0, (LPARAM)&dwi))
			FillRect (hdc, &rc, (HBRUSH)GetStockObject(WHITE_BRUSH));
		
		DrawQuote(hwnd, hdc);

		BitBlt(ps.hdc, 0, 0, nWidth, nHeight, hdc, 0, 0, SRCCOPY);
		DeleteObject(SelectObject(hdc, hbmOld));
		DeleteDC(hdc);

		EndPaint(hwnd, &ps);

		break;
		}
	case WM_CREATE:
		{
			// Init timer
			g_idTimer = 0;
			//g_hIconBmp = LoadBitmap(Instance, MAKEINTRESOURCE(IDB_ICON));
			WCHAR szBitmap[MAX_PATH];
			wcscpy(szBitmap, g_path);
			wcscat(szBitmap, L"\\qotd.bmp");
			g_hIconBmp = SHLoadDIBitmap(szBitmap);
			setNewQuote();
		}
		return 0;

	case WM_TIMER:
		{
			if (wparam == (DWORD)g_idTimer)
			{
				if (g_options.mode == 1)
				{
					if (IsChild(GetForegroundWindow(), hwnd))
					{
						RECT rcQuote;
						
						GetClientRect(hwnd, &rcQuote);
						rcQuote.top += TOPMARGIN;
						rcQuote.left += LEFTMARGIN;
						rcQuote.right -= RIGHTMARGIN;
						rcQuote.bottom -= BOTTOMMARGIN;

						g_scrollPos = ((g_scrollPos + g_options.nScrollSpeed) % g_scrollMax);
						InvalidateRect(hwnd, &rcQuote, TRUE);
					}
				}
				else
					KillTimer(hwnd, g_idTimer);
			}
		}
		return 0;

	case WM_DESTROY:
		DeleteObject(g_hIconBmp);
		return 0;

    default:
      return DefWindowProc(hwnd, msg, wparam, lparam);
  }

  return 0;
}

HWND APIENTRY InitializeCustomItem(TODAYLISTITEM *tli, HWND parent)
{
	SYSTEMTIME SystemTime;
	FILETIME FileTime;
	GetSystemTime( &SystemTime);
	SystemTimeToFileTime( &SystemTime, &FileTime);

	srand( (unsigned)FileTime.dwLowDateTime );

	wcscpy(g_options.szFontName, DEFAULT_FONTNAME);
	g_options.mode = 0;
	g_options.nScrollSpeed = DEFAULT_SCROLL_SPEED;
	g_options.nFontSize = DEFAULT_FONTSIZE;
	g_options.nFontWeight = FW_NORMAL;
	g_options.seq = false;
	g_options.alwaysOne = false;
	g_options.icon = true;
	g_options.nTimeUnit = 0;
	g_options.nTime = 1;

	GetModuleFileName(Instance, g_path, MAX_PATH);
	WCHAR *pName = wcsrchr(g_path, L'\\');
	*pName = 0;

	wcscpy(g_options.szPath, g_path);
	wcscat(g_options.szPath, L"\\qotd.txt");

	// get options from registry
	HKEY hkResult;
	DWORD type;
	DWORD size;
	DWORD ret = 0;
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, L"Software\\Microsoft\\Today\\Items\\QOTD", 0, 0, &hkResult) == ERROR_SUCCESS)
	{
		WCHAR szPath[MAX_PATH];
		size = sizeof(szPath);
		if (RegQueryValueEx(hkResult, L"Path", NULL, &type, (unsigned char *)szPath, &size) == ERROR_SUCCESS && (type == REG_SZ))
			wcscpy(g_options.szPath, szPath);
		size = sizeof(DWORD);
		if (RegQueryValueEx(hkResult, L"Mode", NULL, &type, (unsigned char *)&ret, &size) == ERROR_SUCCESS)
			g_options.mode = ret;
		size = sizeof(DWORD);
		if (RegQueryValueEx(hkResult, L"ScrollSpeed", NULL, &type, (unsigned char *)&ret, &size) == ERROR_SUCCESS)
			g_options.nScrollSpeed = ret;
		WCHAR szFontName[LF_FACESIZE];
		size = sizeof(szFontName);
		if (RegQueryValueEx(hkResult, L"FontName", NULL, &type, (unsigned char *)szFontName, &size) == ERROR_SUCCESS && (type == REG_SZ))
			wcscpy(g_options.szFontName, szFontName);
		size = sizeof(DWORD);
		if (RegQueryValueEx(hkResult, L"FontSize", NULL, &type, (unsigned char *)&ret, &size) == ERROR_SUCCESS)
			g_options.nFontSize = ret;
		size = sizeof(DWORD);
		if (RegQueryValueEx(hkResult, L"FontWeight", NULL, &type, (unsigned char *)&ret, &size) == ERROR_SUCCESS)
			g_options.nFontWeight = ret;
		size = sizeof(DWORD);
		if (RegQueryValueEx(hkResult, L"Seq", NULL, &type, (unsigned char *)&ret, &size) == ERROR_SUCCESS && ret != 0)
			g_options.seq = true;
		size = sizeof(DWORD);
		if (RegQueryValueEx(hkResult, L"AlwaysOne", NULL, &type, (unsigned char *)&ret, &size) == ERROR_SUCCESS && ret != 0)
			g_options.alwaysOne = true;
		size = sizeof(DWORD);
		if (RegQueryValueEx(hkResult, L"Icon", NULL, &type, (unsigned char *)&ret, &size) == ERROR_SUCCESS && ret == 0)
			g_options.icon = false;
		size = sizeof(DWORD);
		if (RegQueryValueEx(hkResult, L"TimeUnit", NULL, &type, (unsigned char *)&ret, &size) == ERROR_SUCCESS)
			g_options.nTimeUnit = ret;
		size = sizeof(DWORD);
		if (RegQueryValueEx(hkResult, L"Time", NULL, &type, (unsigned char *)&ret, &size) == ERROR_SUCCESS)
			g_options.nTime = ret;
		RegCloseKey(hkResult);
	}

	g_currTime = 0;
	g_message[0] = 0;

	Refresh = TRUE;
	return CreateWindow(TEXT("QOTDClass"), TEXT("QOTD"), WS_VISIBLE | WS_CHILD, CW_DEFAULT, CW_DEFAULT, 240, 0, parent, NULL, Instance, NULL);
}

BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:            
        
        // The DLL is being loaded for the first time by a given process.
        // Perform per-process initialization here.  If the initialization
        // is successful, return TRUE; if unsuccessful, return FALSE.
		{
			Instance = (HINSTANCE)hModule;
			WNDCLASS wc;
			wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
			wc.lpfnWndProc = (WNDPROC)WindowProc;
			wc.cbClsExtra = 0;
			wc.cbWndExtra = 0;
			wc.hInstance = Instance;
			wc.hIcon = 0;
			wc.hCursor = 0;
			wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
			wc.lpszMenuName = NULL;
			wc.lpszClassName = TEXT("QOTDClass");
			UnregisterClass(TEXT("QOTDClass"), Instance);
			RegisterClass(&wc);
		}

        break;
        
    case DLL_PROCESS_DETACH:
		{
		UnregisterClass(TEXT("QOTDClass"), Instance);
        Instance = NULL;
		}
        break;           
    }
    
    return TRUE;
}
