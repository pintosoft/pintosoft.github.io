//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by qotd_eng.rc
//
#define IDB_BITMAP1                     101
#define IDB_ICON                        101
#define IDD_PROPPAGE_LARGE              102
#define IDB_ICONMASK                    102
#define IDI_SPRITE                      105
#define IDI_ICON1                       106
#define IDC_STATIC_TITLE                444
#define IDC_STATIC_DESC                 445
#define IDD_TODAY_CUSTOM                500
#define IDC_CHECKTEXT                   1000
#define IDC_CHECKSEQ                    1000
#define IDC_LARGEFONT                   1001
#define IDC_CHECKHELP                   1002
#define IDC_CHECKTODAY                  1003
#define IDC_FIXEDLINE                   1004
#define IDC_PATH                        1004
#define IDC_ALWAYSONE                   1005
#define IDC_FONTNAME                    1007
#define IDC_FONTSIZE                    1008
#define IDC_MODE                        1009
#define IDC_SCROLL_SPEED                1010
#define IDC_BOLD                        1011
#define IDC_TIMEUNIT                    1013
#define IDC_TIME                        1014
#define IDC_SHOWICON                    1015
#define IDC_BROWSE                      1017
#define IDC_BUTTON1                     1020
#define IDC_DEFAULT                     1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
